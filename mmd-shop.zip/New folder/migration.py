import sqlite3

# Connect to the database
conn = sqlite3.connect('STATION_DATA.db')

# Create a cursor object
cur = conn.cursor()

# Create the customers table
# cur.execute('''
#     CREATE TABLE customers
#         (id INTEGER PRIMARY KEY,
#         username TEXT(50) NOT NULL,
#         email TEXT(100) NOT NULL,
#         phone TEXT(15) NOT NULL,
#         registration_date DATE NOT NULL
# )''')


# Create the products table
# cur.execute('''
#     CREATE TABLE products 
#         ( product_id INT PRIMARY KEY,
#         product_name VARCHAR(100) NOT NULL,
#         description TEXT,
#         price DECIMAL(10, 2) NOT NULL,
#         category_id INT NOT NULL      
#     )
# ''')


# Create the orders table
# cur.execute('''
#     CREATE TABLE orders 
#         (order_id INTEGER PRIMARY KEY,
#         customer_id INTEGER NOT NULL,
#         order_date DATETIME NOT NULL,
#         total_value DECIMAL(10,2) NOT NULL,
#         status TEXT(20) NOT NULL,
#         FOREIGN KEY (customer_id) REFERENCES customers(id)
#     )
# ''')


# Create the order_details table
# cur.execute('''
#     CREATE TABLE order_details 
#     (   id INTEGER PRIMARY KEY,
#         order_id INTEGER NOT NULL,
#         product_id INTEGER NOT NULL,
#         quantity INTEGER NOT NULL,
#         unit_price DECIMAL(10,2) NOT NULL,
#         FOREIGN KEY (order_id) REFERENCES orders(id),
#         FOREIGN KEY (product_id) REFERENCES products(id)
#     )
# ''')


# cur.execute('''
#     CREATE TABLE categories (
#         category_id INTEGER PRIMARY KEY,
#         name VARCHAR(50) NOT NULL ,
#         description TEXT,
#         parent_category_id INTEGER,
#         created_at DATETIME DEFAULT CURRENT_TIMESTAMP
#     )
# ''')


# cur.execute('''
#     CREATE TABLE Users (
#         user_id INTEGER PRIMARY KEY,
#         username VARCHAR(50) NOT NULL ,
#         password_hash VARCHAR(100) NOT NULL ,
#         email VARCHAR(100) NOT NULL ,
#         role VARCHAR(20) NOT NULL
        
#     )
# ''')


# cur.execute('''
#     CREATE TABLE Payments (
#         payment_id INTEGER PRIMARY KEY ,
#         order_id INTEGER NOT NULL ,
#         payment_method VARCHAR(50) NOT NULL ,
#         amount DECIMAL(10,2) NOT NULL ,
#         payment_date DATETIME DEFAULT CURRENT_TIMESTAMP ,
#         FOREIGN KEY (order_id) REFERENCES orders(order_id)
#     )
# ''')


# cur.execute('''
#     CREATE TABLE Shipping_Addresses (
#         address_id  INTEGER PRIMARY KEY ,
#         customer_id  INTEGER NOT NULL ,
#         recipient_name VARCHAR(100) NOT NULL ,
#         address_line1 VARCHAR(255) NOT NULL ,
#         address_line2 VARCHAR(255) NOT NULL ,
#         city VARCHAR(100) NOT NULL ,
#         state VARCHAR(100) NOT NULL ,
#         postal_code VARCHAR(20) NOT NULL ,
#         country VARCHAR(100) NOT NULL ,
#         FOREIGN KEY (customer_id) REFERENCES customers(customer_id)
#     )
# ''')


# cur.execute('''
#     CREATE TABLE Feedback (
#         feedback_id INTEGER PRIMARY KEY ,
#         customer_id INTEGER NOT NULL ,
#         order_id INTEGER NOT NULL ,
#         rating INTEGER NOT NULL ,
#         comment TEXT,
#         feedback_date DATETIME DEFAULT CURRENT_TIMESTAMP ,
#         FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ,
#         FOREIGN KEY (order_id) REFERENCES orders(order_id)
#     )
# ''')


# cur.execute('''
#     CREATE TABLE Admin_Logs (
#         log_id INTEGER PRIMARY KEY ,
#         user_id INTEGER NOT NULL ,
#         action VARCHAR(100) NOT NULL ,
#         action_date DATETIME DEFAULT CURRENT_TIMESTAMP ,
#         ip_address VARCHAR(50) NOT NULL ,
#         FOREIGN KEY (user_id) REFERENCES Users(user_id) 
#     )
# ''')
# Commit the changes and close the connection
conn.commit()
conn.close()