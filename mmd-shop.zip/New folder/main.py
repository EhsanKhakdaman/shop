from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

# Connect to the database
def get_db_connection():
    conn = sqlite3.connect('STATION_DATA.db')
    conn.row_factory = sqlite3.Row
    return conn



# Get a customer by ID
def get_customer(customer_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM customers WHERE customer_id = ?', (customer_id,))
    customer = cur.fetchone()
    final_customer = {
            "customer_id": customer[0],
            "name": customer[1],
            "email": customer[2],
            "phone": customer[3],
            "registration_date" : customer[4],
        }
    conn.close()
    return final_customer

# Create a new customer
def create_customer(name, email, phone, registration_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO customers (username, email, phone,registration_date) VALUES (?, ?, ?, ? )', (name, email, phone, registration_date))
    conn.commit()
    customer_id = cur.lastrowid
    conn.close()
    return customer_id

# Create 10 STATION_DATA
# for i in range(1, 11):
#     name = f'Customer {i}'
#     email = f'customer{i}@example.com'
#     phone = f'555-123-456{i}'
#     create_customer(name, email, phone)

# Update a customer
def update_customer(customer_id, name, email, phone,registration_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE customers SET name = ?, email = ?, phone = ?, registration_date = ?  WHERE customer_id = ?', (name, email, phone,registration_date, customer_id))
    conn.commit()
    conn.close()

# Delete a customer
def delete_customer(customer_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM customers WHERE customer_id = ?', (customer_id,))
    conn.commit()
    conn.close()

# Get all STATION_DATA
def get_all_customer():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM customers')
    STATION_DATA = cur.fetchall()
    final_STATION_DATA = []
    for customer in STATION_DATA:
        final_STATION_DATA.append({
            "customer_id": customer[0],
            "name": customer[1],
            "email": customer[2],
            "phone": customer[3],
            "registration_date" : customer[4],
        })
    conn.close()
    return final_STATION_DATA


##-----------Products-------------
# Get a products by ID
def get_product(product_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Products WHERE product_id = ?', (product_id,))
    products = cur.fetchone()
    final_product = {
            "product_id": products[0],
            "product_name": products[1],
            "description": products[2],
            "price": products[3],
            "category_id" : products[4],
        }
    conn.close()
    return final_product

# Create a new products
def create_product( product_name, description, price,category_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Products ( product_name, description, price,category_id) VALUES (?, ?, ?, ? )', ( product_name, description, price,category_id))
    conn.commit()
    product_id = cur.lastrowid
    conn.close()
    return product_id

# Update a products
def update_product( product_id,product_name, description, price,category_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE Products SET product_name = ?, description = ?, price = ?, category_id = ?  WHERE product_id = ?', (product_name, description, price,category_id, product_id))
    conn.commit()
    conn.close()
    
# Delete a products
def delete_product(product_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM Products WHERE product_id = ?', (product_id,))
    conn.commit()
    conn.close()

# Get all STATION_DATA (products)
def get_all_product():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Products')
    STATION_DATA = cur.fetchall()
    final_STATION_DATA = []
    for product in STATION_DATA:
        final_STATION_DATA.append({
            "product_id": product[0],
            "product_name": product[1],
            "description": product[2],
            "price": product[3],
            "category_id" : product[4],
        })
    conn.close()
    return final_STATION_DATA
##------------------categories------------------------------

 # Get a category by ID
def get_category(category_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM categories WHERE category_id = ?', (category_id,))
    category = cur.fetchone()
    final_category = {
            "category_id": category[0],
            "category_name": category[1],
            "description": category[2],
            "parent_category_id": category[3],
            "created_at" : category[4],
        }
    conn.close()
    return final_category

# Create a new category
def create_category( category_name, description, parent_category_id,created_at):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO categories ( category_name, description, parent_category_id,created_at) VALUES (?, ?, ?, ? )', ( category_name, description, parent_category_id,created_at))
    conn.commit()
    category_id = cur.lastrowid
    conn.close()
    return category_id

# Update a category
def update_category( category_id,category_name, description, parent_category_id,created_at):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE categories SET category_name = ?, description = ?, parent_category_id = ?, created_at = ?  WHERE category_id = ?', (category_name, description, parent_category_id,created_at, category_id))
    conn.commit()
    conn.close()
    
# Delete a category
def delete_category(category_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM categories WHERE category_id = ?', (category_id,))
    conn.commit()
    conn.close()
    
# Get all STATION_DATA (categories)
def get_all_category():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM categories')
    STATION_DATA = cur.fetchall()
    final_categories = []
    for category in STATION_DATA:
        final_categories.append({
            "category_id": category[0],
            "category_name": category[1],
            "description": category[2],
            "parent_category_id": category[3],
            "created_at" : category[4],
        })
    conn.close()
    return final_categories

##---------------------orders-------------------------

 # Get a order by ID
def get_order(order_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM orders WHERE order_id = ?', (order_id,))
    order = cur.fetchone()
    final_order = {
            "order_id": order[0],
            "customer_id": order[1],
            "order_date": order[2],
            "total_amount": order[3],
            "status" : order[4],
        }
    conn.close()
    return final_order

# add a new order
def create_order( customer_id, order_date, total_amount,status):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO orders ( customer_id, order_date, total_amount,status) VALUES (?, ?, ?, ? )', ( customer_id, order_date, total_amount,status))
    conn.commit()
    order_id = cur.lastrowid
    conn.close()
    return order_id

# Update a order
def update_order( order_id,customer_id, order_date, total_amount,status):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE orders SET  customer_id = ?, order_date = ?, total_amount = ?,status = ?,  WHERE order_id = ?,', ( order_id,customer_id, order_date, total_amount,status))
    conn.commit()
    conn.close()
    
# Delete a order
def delete_order(order_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM orders WHERE order_id = ?', (order_id,))
    conn.commit()
    conn.close()
    
# Get all STATION_DATA (orders)
def get_all_order():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM orders')
    STATION_DATA = cur.fetchall()
    final_orders = []
    for order in STATION_DATA:
        final_orders.append({
             "order_id": order[0],
            "customer_id": order[1],
            "order_date": order[2],
            "total_amount": order[3],
            "status" : order[4],
        })
    conn.close()
    return final_orders

##---------------------Feedback-------------------------

# Get a Feedback by ID
def get_Feedback(feedback_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Feedback WHERE feedback_id = ?', (feedback_id,))
    Feedback = cur.fetchone()
    final_Feedback = {
            "feedback_id": Feedback[0],
            "customer_id": Feedback[1],
            "order_id": Feedback[2],
            "rating": Feedback[3],
            "comment" : Feedback[4],
            "feedback_date" : Feedback[5],
        }
    conn.close()
    return final_Feedback

# add a new Feedback
def create_Feedback( customer_id, order_id, rating,comment, feedback_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Feedback ( customer_id, order_id, rating,comment, feedback_date) VALUES (?, ?, ?, ? ,?)', ( customer_id, order_id, rating,comment, feedback_date))
    conn.commit()
    feedback_id = cur.lastrowid
    conn.close()
    return feedback_id

# Update a Feedback
def update_Feedback( feedback_id,customer_id, order_id, rating,comment, feedback_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE Feedback SET customer_id = ?, order_id = ?, rating = ?, comment = ?  WHERE feedback_date = ? feedback_id = ?,', ( feedback_id,customer_id, order_id, rating,comment, feedback_date))
    conn.commit()
    conn.close()
    
# Delete a Feedback
def delete_Feedback(feedback_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM Feedback WHERE feedback_id = ?', (feedback_id,))
    conn.commit()
    conn.close()

# Get all STATION_DATA (Feedback)
def get_all_Feedback():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Feedback')
    STATION_DATA = cur.fetchall()
    final_Feedback = []
    for Feedback in STATION_DATA:
        final_Feedback.append({
              "feedback_id": Feedback[0],
            "customer_id": Feedback[1],
            "order_id": Feedback[2],
            "rating": Feedback[3],
            "comment" : Feedback[4],
            "feedback_date" : Feedback[5],
        })
    conn.close()
    return final_Feedback

##---------------------order_details-------------------------

# Get a order_details by ID
def get_order_details(order_details_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM order_details WHERE order_details_id = ?', (order_details_id,))
    order_details = cur.fetchone()
    final_order_details = {
            "order_details_id": order_details[0],
            "order_id": order_details[1],
            "product_id": order_details[2],
            "quantity": order_details[3],
            "unit_price" : order_details[4],
            
        }
    conn.close()
    return final_order_details

# add a new order_details
def create_order_details( order_id, product_id, quantity, unit_price):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO order_details ( order_id, product_id, quantity, unit_price) VALUES (?, ?, ?, ? )', ( order_id, product_id, quantity, unit_price))
    conn.commit()
    order_details_id = cur.lastrowid
    conn.close()
    return order_details_id

# Update a order_details
def update_order_details( order_details_id,order_id, product_id, quantity, unit_price):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE order_details SET   order_id = ?, product_id = ?, quantity = ?,unit_price = ?,  WHERE order_details_id = ?', ( order_details_id,order_id, product_id, quantity, unit_price))
    conn.commit()
    conn.close()
    
# Delete a order_details
def delete_order_details(order_details_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM order_details WHERE order_details_id = ?', (order_details_id,))
    conn.commit()
    conn.close()

# Get all STATION_DATA (order_details)
def get_all_order_details():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM order_details')
    STATION_DATA = cur.fetchall()
    final_order_details = []
    for order_details in STATION_DATA:
        final_order_details.append({
             "order_details_id": order_details[0],
            "order_id": order_details[1],
            "product_id": order_details[2],
            "quantity": order_details[3],
            "unit_price" : order_details[4],
        })
    conn.close()
    return final_order_details

##---------------------Payments-------------------------

# Get a Payments by ID
def get_Payments(payment_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Payments WHERE payment_id = ?', (payment_id,))
    Payments = cur.fetchone()
    final_Payments = {
            "payment_id": Payments[0],
            "order_id": Payments[1],
            "payment_method": Payments[2],
            "amount": Payments[3],
            "payment_date" : Payments[4],
            
        }
    conn.close()
    return final_Payments

# add a new Payments
def create_Payments( order_id, payment_method, amount, payment_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Payments ( order_id, payment_method, amount, payment_date) VALUES (?, ?, ?, ? )', ( order_id, payment_method, amount, payment_date))
    conn.commit()
    payment_id = cur.lastrowid
    conn.close()
    return payment_id

# Update a Payments
def update_Payments( payment_id,order_id, payment_method, amount, payment_date):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE Payments SET   order_id = ?, product_id = ?, amount = ?, payment_date = ? , WHERE  payment_id = ?', ( payment_id,order_id, payment_method, amount, payment_date))
    conn.commit()
    conn.close()
    
# Delete a Payments
def delete_Payments(payment_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM order_details WHERE payment_id = ?', (payment_id,))
    conn.commit()
    conn.close()
    
# Get all STATION_DATA (Payments)
def get_all_Payments():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Payments')
    STATION_DATA = cur.fetchall()
    final_Payments = []
    for Payments in STATION_DATA:
        final_Payments.append({
           "payment_id": Payments[0],
            "order_id": Payments[1],
            "payment_method": Payments[2],
            "amount": Payments[3],
            "payment_date" : Payments[4],
            
        })
    conn.close()
    return final_Payments


##---------------------Shipping_Addresses-------------------------

# Get a Shipping_Addresses by ID
def get_Shipping_Addresses(address_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Payments WHERE address_id = ?', (address_id,))
    Shipping_Addresses = cur.fetchone()
    final_Shipping_Addresses = {
            "address_id": Shipping_Addresses[0],
            "customer_id": Shipping_Addresses[1],
            "recipient_name": Shipping_Addresses[2],
            "address_line1": Shipping_Addresses[3],
            "address_line2" : Shipping_Addresses[4],
            "City": Shipping_Addresses[5],
            "state": Shipping_Addresses[6],
            "postal_code" : Shipping_Addresses[7],
            "country" :  Shipping_Addresses[8],
            
        }
    conn.close()
    return final_Shipping_Addresses

# add a new Shipping_Addresses
def create_Payments( address_id, customer_id, recipient_name, address_line1,address_line2,City,state,postal_code,country):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Shipping_Addresses ( address_id, customer_id, recipient_name, address_line1,address_line2,City,state,postal_code,country) VALUES (?, ?, ?, ? ,? ,? ,? ,? , ? )', ( address_id, customer_id, recipient_name, address_line1,address_line2,City,state,postal_code,country))
    conn.commit()
    payment_id = cur.lastrowid
    conn.close()
    return payment_id

# Delete a Shipping_Addresses
def delete_Shipping_Addresses(address_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM Shipping_Addresses WHERE address_id = ?', (address_id,))
    conn.commit()
    conn.close()
    
# Get all STATION_DATA (Shipping_Addresses)
def get_all_Shipping_Addresses():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Shipping_Addresses')
    STATION_DATA = cur.fetchall()
    final_Shipping_Addresses = []
    for Shipping_Addresses in STATION_DATA:
        final_Shipping_Addresses.append({
            "address_id": Shipping_Addresses[0],
            "customer_id": Shipping_Addresses[1],
            "recipient_name": Shipping_Addresses[2],
            "address_line1": Shipping_Addresses[3],
            "address_line2" : Shipping_Addresses[4],
            "City": Shipping_Addresses[5],
            "state": Shipping_Addresses[6],
            "postal_code" : Shipping_Addresses[7],
            "country" :  Shipping_Addresses[8],
            
        })
    conn.close()
    return final_Shipping_Addresses

##---------------------Admin_Logs-------------------------

# Get a Admin_Logs by ID
def get_Admin_Logs(log_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Admin_Logs WHERE log_id = ?', (log_id,))
    Admin_Logs = cur.fetchone()
    final_Admin_Logs = {
            "log_id": Admin_Logs[0],
            "user_id": Admin_Logs[1],
            "action": Admin_Logs[2],
            "action_date": Admin_Logs[3],
            "ip_address" : Admin_Logs[4],
            
        }
    conn.close()
    return final_Admin_Logs 

# add a new Admin_Logs
def create_Admin_Logs( user_id, action, action_date, ip_address):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('INSERT INTO Admin_Logs ( user_id, action, action_date, ip_address) VALUES (?, ?, ?, ? )', ( user_id, action, action_date, ip_address))
    conn.commit()
    log_id = cur.lastrowid
    conn.close()
    return log_id

# Update a Admin_Logs
def update_Admin_Logs(log_id ,user_id, action, action_date, ip_address):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('UPDATE Admin_Logs SET   user_id = ?, action = ?, action_date = ?, ip_address = ? , WHERE  log_id = ?', (log_id ,user_id, action, action_date, ip_address))
    conn.commit()
    conn.close()
    
# Delete a Admin_Logs
def delete_Admin_Logs(log_id):
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('DELETE FROM Admin_Logs WHERE log_id = ?', (log_id,))
    conn.commit()
    conn.close()
    
# Get all STATION_DATA (Admin_Logs)
def get_all_Admin_Logs():
    conn = get_db_connection()
    cur = conn.cursor()
    cur.execute('SELECT * FROM Admin_Logs')
    STATION_DATA = cur.fetchall()
    final_Payments = []
    for Admin_Logs in STATION_DATA:
        final_Admin_Logs = {
            "log_id": Admin_Logs[0],
            "user_id": Admin_Logs[1],
            "action": Admin_Logs[2],
            "action_date": Admin_Logs[3],
            "ip_address" : Admin_Logs[4],
            
        }
    conn.close()
    return final_Admin_Logs
#===============================================================
# CRUD routes
@app.route('/customer', methods=['GET'])
def list_customer():
    customer = get_all_customer()
    return jsonify(customer)

@app.route('/customer', methods=['POST'])
def add_customer():
    name = request.json['name']
    email = request.json['email']
    phone = request.json['phone']
    registration_date = request.json['registration_date']
    
    customer_id = create_customer(name, email, phone)
    return jsonify({'customer_id': customer_id}), 201

@app.route('/customer/<int:customer_id>', methods=['GET'])
def get_customer_by_id(customer_id):
    customer = get_customer(customer_id)
    if customer is None:
        return '', 404
    return jsonify(customer), 200

@app.route('/customer/<int:customer_id>', methods=['PUT'])
def update_customer_by_id(customer_id):
    name = request.json['name']
    email = request.json['email']
    phone = request.json['phone']
    registration_date = request.json['registration_date']
    update_customer(customer_id, name, email, phone,registration_date)
    return '', 204

@app.route('/customer/<int:customer_id>', methods=['DELETE'])
def delete_customer_by_id(customer_id):
    delete_customer(customer_id)
    return '', 204
#-----------products--------------------------------
@app.route('/product', methods=['GET'])
def list_product():
    product = get_all_product()
    return jsonify(product)

@app.route('/product', methods=['POST'])
def add_product():
    product_name = request.json['product_name']
    description = request.json['description']
    price = request.json['price']
    category_id = request.json['category_id']
    
    product_id = create_product(product_name, description, price,category_id)
    return jsonify({'product_id': product_id}), 201

@app.route('/product/<int:product_id>', methods=['GET'])
def get_product_by_id(product_id):
    product = get_product(product_id)
    if product is None:
        return '', 404
    return jsonify(product), 200

@app.route('/product/<int:product_id>', methods=['PUT'])
def update_product_by_id(product_id):
    product_name = request.json['product_name']
    description = request.json['description']
    price = request.json['price']
    category_id = request.json['category_id']
    update_product(product_id,product_name, description, price,category_id)
    return '', 204

@app.route('/product/<int:product_id>', methods=['DELETE'])
def delete_product_by_id(product_id):
    delete_product(product_id)
    return '', 204

##------------------categories------------------------------

@app.route('/category', methods=['GET'])
def list_category():
    category = get_all_category()
    return jsonify(category)

@app.route('/category', methods=['POST'])
def add_category():
    category_name = request.json['category_name']
    description = request.json['description']
    parent_category_id = request.json['price']
    created_at = request.json['created_at']
 
    category_id = create_category(category_name, description, parent_category_id,created_at)
    return jsonify({'category_id': category_id}), 201

@app.route('/category/<int:category_id>', methods=['GET'])
def get_category_by_id(category_id):
    category = get_category(category_id)
    if category is None:
        return '', 404
    return jsonify(category), 200

@app.route('/category/<int:category_id>', methods=['PUT'])
def update_categoryby_id(category_id):
    category_name = request.json['category_name']
    description = request.json['description']
    parent_category_id = request.json['price']
    created_at = request.json['category_id']
    update_category(category_id,category_name, description, parent_category_id,created_at)
    return '', 204

@app.route('/category/<int:category_id>', methods=['DELETE'])
def delete_category_by_id(category_id):
    delete_category(category_id)
    return '', 204

##---------------------orders-------------------------

@app.route('/orders', methods=['GET'])
def list_orders():
    orders = get_all_order()
    return jsonify(orders)

@app.route('/orders', methods=['POST'])
def add_order():
    customer_id = request.json['customer_id']
    order_date = request.json['order_date']
    total_amount = request.json['total_amount']
    status = request.json['status']
 
    order_id = create_order(customer_id, order_date, total_amount,status)
    return jsonify({'order_id': order_id}), 201

@app.route('/orders/<int:order_id>', methods=['GET'])
def get_orders_by_id(order_id):
    orders = get_order(order_id)
    if orders is None:
        return '', 404
    return jsonify(orders), 200

# @app.route('/orders/<int:order_id>', methods=['PUT'])
# def update_product_by_id(order_id):
#     customer_id = request.json['customer_id']
#     order_date = request.json['order_date']
#     total_amount = request.json['total_amount']
#     status = request.json['status']
#     update_order(order_id,customer_id, order_date, total_amount,status)
#     return '', 204

@app.route('/orders/<int:order_id>', methods=['DELETE'])
def delete_order_by_id(order_id):
    delete_order(order_id)
    return '', 204

##---------------------Feedback-------------------------

@app.route('/Feedback', methods=['GET'])
def list_Feedback():
    Feedback = get_all_Feedback()
    return jsonify(Feedback)

@app.route('/Feedback', methods=['POST'])
def add_Feedback():
    
    feedback_id = request.json['feedback_id']
    customer_id = request.json['customer_id']
    order_id = request.json['order_id']
    rating = request.json['rating']
    comment = request.json['comment']
    feedback_date = request.json['feedback_date']
 
    feedback_id = create_Feedback(customer_id, order_id, rating, comment,feedback_date)
    return jsonify({'feedback_id': feedback_id}), 201

app.route('/Feedback/<int:feedback_id>', methods=['GET'])
def get_Feedback_by_id(feedback_id):
    Feedback = get_Feedback(feedback_id)
    if Feedback is None:
        return '', 404
    return jsonify(Feedback), 200

@app.route('/Feedback/<int:feedback_id>', methods=['PUT'])
def update_Feedback_by_id(feedback_id):
    feedback_id = request.json['feedback_id']
    customer_id = request.json['customer_id']
    order_id = request.json['order_id']
    rating = request.json['rating']
    comment = request.json['comment']
    feedback_date = request.json['feedback_date']
    update_Feedback(feedback_id,customer_id, order_id, rating,comment,feedback_date)
    return '', 204

@app.route('/Feedback/<int:feedback_id>', methods=['DELETE'])
def delete_Feedback_by_id(feedback_id):
    delete_Feedback(feedback_id)
    return '', 204

##---------------------order_details-------------------------

@app.route('/order_details', methods=['GET'])
def list_order_details():
    order_details = get_all_order_details()
    return jsonify(order_details)

@app.route('/order_details', methods=['POST'])
def add_order_details():
    
    order_details_id = request.json['order_details_id']
    order_id = request.json['order_id']
    product_id = request.json['product_id']
    quantity = request.json['quantity']
    unit_price = request.json['unit_price']
 
    order_details_id = create_order_details(order_id, product_id, quantity, unit_price)
    return jsonify({'feedback_id': order_details_id}), 201

app.route('/order_details/<int:order_details_id>', methods=['GET'])
def get_order_details_by_id(order_details_id):
    order_details = get_order_details(order_details_id)
    if order_details is None:
        return '', 404
    return jsonify(order_details), 200

@app.route('/order_details/<int:order_details_id>', methods=['PUT'])
def update_order_details_by_id(order_details_id):
        order_details_id = request.json['order_details_id']
        order_id = request.json['order_id']
        product_id = request.json['product_id']
        quantity = request.json['quantity']
        unit_price = request.json['unit_price']
 
        update_order_details(order_details_id,order_id, product_id, quantity, unit_price)
        return '', 204\
            
@app.route('/order_details/<int:order_details_id>', methods=['DELETE'])
def delete_order_details_by_id(order_details_id):
    delete_order_details(order_details_id)
    return '', 204

##---------------------Payments-------------------------

@app.route('/Payments', methods=['GET'])
def list_Payments():
    Payments = get_all_Payments()
    return jsonify(Payments)

@app.route('/Payments', methods=['POST'])
def add_Payments():
    
    payment_id = request.json['payment_id']
    order_id = request.json['order_id']
    payment_method = request.json['payment_method']
    amount = request.json['amount']
    payment_date = request.json['payment_date']
 
    payment_id = create_Payments(order_id, payment_method, amount, payment_date)
    return jsonify({'payment_id': payment_id}), 201

app.route('/Payments/<int:payment_id>', methods=['GET'])
def get_Payments_by_id(payment_id):
    Payments = get_Payments(payment_id)
    if Payments is None:
        return '', 404
    return jsonify(Payments), 200

@app.route('/Payments/<int:payment_id>', methods=['PUT'])
def update_Payments_by_id(payment_id):
        payment_id = request.json['order_details_id']
        order_id = request.json['order_id']
        payment_method = request.json['payment_method']
        amount = request.json['amount']
        payment_date = request.json['payment_date']
 
        update_Payments(payment_id,order_id, payment_method, amount, payment_date)
        return '', 204\
            
# @app.route('/Payments/<int:payment_id>', methods=['DELETE'])
# def delete_Payments_by_id(payment_id):
#     delete_Payments(payment_id)
#     return '', 204

##---------------------Shipping_Addresses-------------------------

@app.route('/Shipping_Addresses', methods=['GET'])
def list_Shipping_Addresses():
    Shipping_Addresses = get_all_Shipping_Addresses()
    return jsonify(Shipping_Addresses)

app.route('/Shipping_Addresses/<int:address_id>', methods=['GET'])
def get_Shipping_Addresses_by_id(address_id):
    Shipping_Addresses = get_Payments(address_id)
    if Shipping_Addresses is None:
        return '', 404
    return jsonify(Shipping_Addresses), 200

@app.route('/Shipping_Addresses/<int:address_id>', methods=['DELETE'])
def delete_Shipping_Addresses_by_id(address_id):
    delete_Shipping_Addresses(address_id)
    return '', 204

##---------------------Admin_Logs-------------------------

@app.route('/Admin_Logs', methods=['GET'])
def list_Admin_Logs():
    Admin_Logs = get_all_Admin_Logs()
    return jsonify(Admin_Logs)

@app.route('/Admin_Logs', methods=['POST'])
def add_Admin_Logs():
    
    log_id = request.json['log_id']
    user_id = request.json['user_id']
    action = request.json['action']
    action_date = request.json['action_date']
    ip_address = request.json['ip_address']
 
    log_id = create_Payments(user_id, action, action_date, ip_address)
    return jsonify({'log_id': log_id}), 201

app.route('/Admin_Logs/<int:log_id>', methods=['GET'])
def get_Admin_Logs_by_id(log_id):
    Admin_Logs = get_Admin_Logs(log_id)
    if Admin_Logs is None:
        return '', 404
    return jsonify(Admin_Logs), 200

@app.route('/Admin_Logs/<int:log_id>', methods=['PUT'])
def update_Admin_Logs_by_id(log_id):
        log_id = request.json['log_id']
        user_id = request.json['user_id']
        action = request.json['action']
        action_date = request.json['action_date']
        ip_address = request.json['ip_address']
 
        update_Admin_Logs(log_id,user_id, action, action_date, ip_address)
        return '', 204\
            
@app.route('/Admin_Logs/<int:log_id>', methods=['DELETE'])
def delete_Payments_by_id(payment_id):
    delete_Payments(payment_id)
    return '', 204
##################################
    
#test backend
@app.route('/', methods=['GET'])
def test():
    return "ok"


if __name__ == '__main__':
     app.run(port=5173)
     app.run(debug=True)