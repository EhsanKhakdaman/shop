import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const Feedback_Creat = () => (
    <Create>
        <SimpleForm>
            <TextInput source="feedback_id" validate={[required()]} fullWidth />
            <TextInput source="customer_id" multiline={true} label="customer_id" />
            <TextInput source="order_id" multiline={true} label="order_id" />
            <TextInput source="rating" multiline={true} label="rating" />
            <TextInput source="comment" multiline={true} label="comment" />
            <DateInput source='feedback_date' validate={[required()]} fullWidth />
        </SimpleForm>
    </Create>
);
