import {
    CreateButton,
    Datagrid,
    FilterButton,
    FilterForm,
    ListBase,
    List,
    Pagination,
    TextField,
    TextInput,
    SearchInput,
    EmailField,
    DateField,
} from 'react-admin';
import { Stack } from '@mui/material';

const Feedback_Filters = [
    <SearchInput source="feedback_id" alwaysOn />,
    <TextInput label="feedback_date" source="feedback_date" defaultValue="2000/11/11" />,
];
const ListToolbar = () => (
    <Stack direction="row" justifyContent="space-between">
        <FilterForm filters={Feedback_Filters} />
        <div>
            <FilterButton filters={Feedback_Filters} />
            <CreateButton />
        </div>
    </Stack>
)
export const Feedback_List = () => (
    <List>
        <ListToolbar />
        <Datagrid rowClick="edit">
            <TextField source="feedback_id" />
            <TextField source="customer_id" />
            <DateField source="order_id" />
            <TextField source="rating" />
            <TextField source="comment" />
            <DateField source="feedback_date" />
        </Datagrid>
    </List>
);