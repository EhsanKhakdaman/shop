import {
    CreateButton,
    Datagrid,
    FilterButton,
    FilterForm,
    ListBase,
    List,
    Pagination,
    TextField,
    TextInput,
    SearchInput,
    EmailField,
    DateField,
} from 'react-admin';
import { Stack } from '@mui/material';

const orderFilters = [
    <SearchInput source="order_id" alwaysOn />,
    <TextInput label="cusutomer_id" source="cusutomer_id" defaultValue="1" />,
];
const ListToolbar = () => (
    <Stack direction="row" justifyContent="space-between">
        <FilterForm filters={orderFilters} />
        <div>
            <FilterButton filters={orderFilters} />
            <CreateButton />
        </div>
    </Stack>
)
export const OrdersList = () => (
    <List>
        <ListToolbar />
        <Datagrid rowClick="edit">
            <TextField source="order_id" />
            <TextField source="customer_id" />
            <DateField source="order_date" />
            <TextField source="total_amount" />
            <TextField source="status" />
        </Datagrid>
    </List>
);