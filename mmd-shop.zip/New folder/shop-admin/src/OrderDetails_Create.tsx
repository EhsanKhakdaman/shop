import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const OrderDetails_Creat = () => (
    <Create>
        <SimpleForm>
            <TextInput source="order_details_id" validate={[required()]} />
            <TextInput source="order_id" multiline={true}/>
            <TextInput source="product_id"/>
            <TextInput source="quantity"/>
            <TextInput source="unit_price"/>

        </SimpleForm>
    </Create>
);