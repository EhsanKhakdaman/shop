import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const OrderCreat = () => (
    <Create>
        <SimpleForm>
            <TextInput source="order_id" validate={[required()]} />
            <TextInput source="customer_id" multiline={true}/>
            <TextInput source="order_date"/>
        </SimpleForm>
    </Create>
);