import {
    CreateButton,
    Datagrid,
    FilterButton,
    FilterForm,
    ListBase,
    List,
    Pagination,
    TextField,
    TextInput,
    SearchInput,
    EmailField,
    DateField,
} from 'react-admin';
import { Stack } from '@mui/material';

const orderdetailsFilters = [
    <SearchInput source="order_details_id" alwaysOn />,
    <TextInput label="order_id" source="order_id" defaultValue="1" />,
];
const ListToolbar = () => (
    <Stack direction="row" justifyContent="space-between">
        <FilterForm filters={orderdetailsFilters} />
        <div>
            <FilterButton filters={orderdetailsFilters} />
            <CreateButton />
        </div>
    </Stack>
)
export const Order_details_list = () => (
    <List>
        <ListToolbar />
        <Datagrid rowClick="edit">
            <TextField source="order_details_id" />
            <TextField source="order_id" />
            <DateField source="product_id" />
            <TextField source="quantity" />
            <TextField source="unit_price" />
        </Datagrid>
    </List>
);