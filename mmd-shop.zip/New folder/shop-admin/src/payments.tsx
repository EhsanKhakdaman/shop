import {
    CreateButton,
    Datagrid,
    FilterButton,
    FilterForm,
    ListBase,
    List,
    Pagination,
    TextField,
    TextInput,
    SearchInput,
    EmailField,
    DateField,
} from 'react-admin';
import { Stack } from '@mui/material';

const PaymentsFilters = [
    <SearchInput source="payment_id" alwaysOn />,
    <TextInput label="payment_date" source="payment_date" defaultValue="2000/11/11" />,
];
const ListToolbar = () => (
    <Stack direction="row" justifyContent="space-between">
        <FilterForm filters={PaymentsFilters} />
        <div>
            <FilterButton filters={PaymentsFilters} />
            <CreateButton />
        </div>
    </Stack>
)
export const Payment_list = () => (
    <List>
        <ListToolbar />
        <Datagrid rowClick="edit">
            <TextField source="payment_id" />
            <TextField source="order_id" />
            <DateField source="payment_method" />
            <TextField source="amount" />
            <DateField source="payment_date" />
        </Datagrid>
    </List>
);