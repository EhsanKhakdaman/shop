import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const CustomerCreate = () => (
    <Create>
        <SimpleForm>
            <TextInput source="username" validate={[required()]} fullWidth />
            <TextInput source="email" multiline={true} label="email" />
            <TextInput source="phone" multiline={true} label="phone" />
            <DateInput source='Registration Date' validate={[required()]} fullWidth />
        </SimpleForm>
    </Create>
);