import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const Payment_Creat = () => (
    <Create>
        <SimpleForm>
            <TextInput source="payment_id" validate={[required()]} />
            <TextInput source="order_id" multiline={true}/>
            <TextInput source="order_id" />
            <DateInput source="payment_method"/>
            <TextInput source="amount" />
            <DateInput source="payment_date"/>

        </SimpleForm>
    </Create>
);