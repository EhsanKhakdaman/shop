import {
    CreateButton,
    Datagrid,
    FilterButton,
    FilterForm,
    ListBase,
    List,
    Pagination,
    TextField,
    TextInput,
    SearchInput,
    EmailField,
    DateField,
} from 'react-admin';
import { Stack } from '@mui/material';

const ProductsFilters = [
    <SearchInput source="product_name" alwaysOn />,
    <TextInput label="price" source="price" defaultValue="10000" />,
];
const ListToolbar = () => (
    <Stack direction="row" justifyContent="space-between">
        <FilterForm filters={ProductsFilters} />
        <div>
            <FilterButton filters={ProductsFilters} />
            <CreateButton />
        </div>
    </Stack>
)
export const Product_list = () => (
    <List>
        <ListToolbar />
        <Datagrid rowClick="edit">
            <TextField source="product_id" />
            <TextField source="product_name" />
            <TextField source="description" />
            <TextField source="price" />
            <TextField source="category_id" />
        </Datagrid>
    </List>
);