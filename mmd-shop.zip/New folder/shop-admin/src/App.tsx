import {
  Admin,
  Resource,
  ListGuesser,
  EditGuesser,
  ShowGuesser,
} from "react-admin";
import { dataProvider } from "./dataProvider";
import { authProvider } from "./authProvider";
import { CategoryList } from "./category";
import { CategoryCreat } from "./categoryCreat";
import { OrdersList } from "./orders";
import { OrderCreat } from "./orderCreate";
import { Order_details_list } from "./orderdetails";
import { OrderDetails_Creat } from "./OrderDetails_Create";
import { Payment_list } from "./payments";
import { Payment_Creat } from "./PaymentCreate";
import { Product_list } from "./Products";
import { Products_Creat } from "./CreateProducts";
import { Feedback_List } from "./Feedback_list";
import { Feedback_Creat } from "./Feedback_Create";
import { CustomersList } from "./Customers";
import { CustomerCreate } from "./CustomerCreate";

export const App = () => (
  <Admin dataProvider={dataProvider} authProvider={authProvider}>
    <Resource
      name="Orders"
      list={OrdersList}
      edit={EditGuesser}
      show={ShowGuesser}
      create={OrderCreat}
    />
    <Resource
      name="Order_Details"
      list={Order_details_list}
      edit={EditGuesser}
      show={ShowGuesser}
      create={OrderDetails_Creat}
    />
    <Resource
      name="Payments"
      list={Payment_list}
      edit={EditGuesser}
      show={ShowGuesser}
      create={Payment_Creat}
    />
    <Resource
      name="Categories"
      list={CategoryList}
      edit={EditGuesser}
      show={EditGuesser}
      create={CategoryCreat}
    />
    <Resource
      name="Products"
      list={Product_list}
      edit={EditGuesser}
      show={ShowGuesser}
      create={Products_Creat}
    />
    <Resource
      name="Feedback"
      list={Feedback_List}
      edit={EditGuesser}
      show={ShowGuesser}
      create={Feedback_Creat}
    />
    <Resource
      name="customer"
      list={CustomersList}
      edit={EditGuesser}
      show={ShowGuesser}
      create={CustomerCreate}
    />
  </Admin>
);
