import * as React from 'react';
import { Create, SimpleForm, TextInput, DateInput, required } from 'react-admin';

export const Products_Creat = () => (
    <Create>
        <SimpleForm>
            <TextInput source="product_name" validate={[required()]} fullWidth />
            <TextInput source="description" multiline={true} label="description" />
            <TextInput source="price" multiline={true} label="price" />
            <DateInput source='category_id' validate={[required()]} fullWidth />
        </SimpleForm>
    </Create>
);
